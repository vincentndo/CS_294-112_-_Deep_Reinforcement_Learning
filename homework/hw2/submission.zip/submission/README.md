# CS294-112 HW 2: Policy Gradient

Dependencies:
 * Python **3.5**
 * Numpy version **1.14.5**
 * TensorFlow version **1.10.5**
 * MuJoCo version **1.50** and mujoco-py **1.50.1.56**
 * OpenAI Gym version **0.10.5**
 * seaborn
 * Box2D==**2.3.2**
 * tensorflow_probability
 * scikit-learn

Before executing, install requirements.txt. The coding is `train_pg_f18.py`, the report is in the report folder.

Execute the command lines as in the report.
