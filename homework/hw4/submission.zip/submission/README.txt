1. Install package tensorflow_probability

2. Using flag --CEM_mode to run CEM

3. Change max_iter in model_based_policy.py to adjust the number of iterations in the CEM algorithm.

