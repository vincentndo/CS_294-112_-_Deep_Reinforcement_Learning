1. install requirement
2. download all the original file, i.e. run_expert.py, load_policy, etc.
2. create a folder name "output"
4. open each files run all cells

